package com.tajir.ayoub;
import java.util.List;
import java.util.ArrayList;
 

public class ProductCategory {
    private String categoryName;
    private List<Product> productList;

    public ProductCategory(String categoryName) {
        this.categoryName = categoryName;
        productList = new ArrayList<>();
    }

    public String getCategoryName() {
        return categoryName;
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void addProduct(Product product) {
        productList.add(product);
    }
}

