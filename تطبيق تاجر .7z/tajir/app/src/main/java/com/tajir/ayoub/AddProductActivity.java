package com.tajir.ayoub;
 import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
//import androidx.appcompat.app.AppCompatActivity;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.content.Context;
import android.annotation.Nullable;
import java.io.File;
import android.os.Environment;
import android.widget.Toast;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import android.support.v7.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.support.v4.content.FileProvider;
import java.util.Date;
import java.text.SimpleDateFormat;
import android.support.v7.widget.Toolbar;
import com.squareup.picasso.Picasso;
import android.view.LayoutInflater;

public class AddProductActivity extends AppCompatActivity {
	private ImageView img;
	Context context;
    private EditText productNameEditText;
    private EditText productPriceEditText;
    private EditText purchasePriceEditText;
	private EditText discriptionEditText;
    private ImageView selectImageButton;
    private Button saveProductButton,cancel;
    private String selectedImagePath; // لتخزين مسار الصورة المختارة
	//private String selectedImagePath = null;
	private int selectedImageSource = -1; // 0 for camera, 1 for gallery
	String x;
	AlertDialog dialogim;
	String productName;
	String productdiscription;
	double purchasePrice;
	double productPrice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.AddProductActivity);
		
//img=findViewById(R.id.imageView);
		createProductImagesFolder();
		
		Toolbar toolbar=(Toolbar)findViewById(R.id.toolbars);
        setSupportActionBar(toolbar);
		
		
		
		discriptionEditText=findViewById(R.id.discretionEditText);
        productNameEditText = findViewById(R.id.productNameEditText);
        productPriceEditText = findViewById(R.id.productPriceEditText);
        purchasePriceEditText = findViewById(R.id.purchasePriceEditText);
	   cancel= findViewById(R.id.cancelProductButton);
        saveProductButton = findViewById(R.id.saveProductButton);

        selectImageButton = findViewById(R.id.selectImageButton);

selectImageButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
		
		showImageSourceSelectionDialog();
		
  
    }

	
	
    
    private void showImageSourceSelectionDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(AddProductActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.camera_galery_alert, null);
        builder.setView(dialogView);
       Button btcamera = dialogView.findViewById(R.id.camera);
		Button btgallery = dialogView.findViewById(R.id.gallery);
		btcamera.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					selectedImageSource = 0;
                    try {
                        openCamera();
                    } catch (IOException e) {
                        // يمكنك هنا استخدام الصورة الافتراضية في حالة حدوث خطأ
                       // selectedImagePath = getRealPathFromResource(R.drawable.ic_image_remove);
                    }
				}
				
		   
	   });
		btgallery.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					selectedImageSource = 1;
                    try {
                        openGallery();
                    } catch (Exception e) {
                        // يمكنك هنا استخدام الصورة الافتراضية في حالة حدوث خطأ
						// selectedImagePath = getRealPathFromResource(R.drawable.ic_image_remove);
                    }
				}


			});


         dialogim= builder.create();





        dialogim.show();

    }
		
		
		
		
        

    // دالة للحصول على مسار الصورة الافتراضية في حالة عدم توفر الصورة
    private String getRealPathFromResource(int resourceId) {
        Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + resourceId);
        return uri.toString();
    }
});

	
	
	
		cancel.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					
					Intent intent = new Intent(AddProductActivity.this, MainActivity.class);
					startActivity(intent);
				}
				
	
});


		saveProductButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					try{
					if(selectedImagePath==null){
						// قم بتحميل وعرض الصورة إذا كانت متاحة
							// إذا كانت المسار فارغًا، يمكنك عرض صورة افتراضية أو التعامل معها كما تشاء
							// يمكنك تعيين صورة افتراضية لـ holder.productImageView
					     selectImageButton.setImageResource(R.drawable.ic_image_plus);
						

						
					}
				
								productName = productNameEditText.getText().toString();
								productPrice = Double.parseDouble(productPriceEditText.getText().toString());
								purchasePrice = Double.parseDouble(purchasePriceEditText.getText().toString());
								productdiscription=discriptionEditText.getText().toString();
						
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

					Date currentTime = new Date();

					// تنسيق وعرض الوقت الحالي
					String formattedTime = sdf.format(currentTime);
							
				           // عليه format بدون أن نطبق أي Date هنا قمنا بعرض الـ
				    x=  String.valueOf( formattedTime );   // عليه format مع تطبيق الـ Date هنا قمنا بعرض الـ
					
								
								
								
								// قم بحفظ المعلومات في قاعدة البيانات
								ProductDatabase productDatabase = new ProductDatabase(AddProductActivity.this);
								productDatabase.addProduct(productName, productPrice, purchasePrice, selectedImagePath,productdiscription,x);
						ProductAdapter	productAdapter = new ProductAdapter(AddProductActivity.this);
						productAdapter.notifyDataSetChanged();
								// تم حفظ المعلومات بنجاح
								Toast.makeText(AddProductActivity.this, "تم حفظ المنتج بنجاح", Toast.LENGTH_LONG).show();

								// قم بمسح الحقول بعد الحفظ
								productNameEditText.setText("");
								productPriceEditText.setText("");
								purchasePriceEditText.setText("");
							    discriptionEditText.setText("");
				                recreate();
					
					}catch(Exception e){
						String d  = productdiscription="بدون اسم";
						double ph=  purchasePrice=0;
						double ppc =   productPrice=0;
						String n= productName="بدون وصف";
						//  selectImageButton.setImageResource(R.drawable.ic_database_remove);
						//selectImageButton.setImageResource(R.drawable.ic_image_plus);
						
						String img=  selectedImagePath=getRealPathFromResource(R.drawable.ic_image);
						Picasso.with(AddProductActivity.this).load(new File(img)).into(selectImageButton);
						
						
						ProductDatabase productDatabase = new ProductDatabase(AddProductActivity.this);
						productDatabase.addProduct(n, ppc, ph, img,d,x);
						ProductAdapter	productAdapter = new ProductAdapter(AddProductActivity.this);
						productAdapter.notifyDataSetChanged();
						
						Toast.makeText(AddProductActivity.this, "تم الحفض ولاكن احد الحقول مفقودة ", Toast.LENGTH_LONG).show();
						
						
					}
					
				}

				private String getRealPathFromResource(int ic_image_remove) {
					Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + ic_image_remove);
					return uri.toString();
				
				}

// دالة لنسخ الملف6ff
			});}

	private void createProductImagesFolder(){

		File productImagesFolder = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "product_images");
		if (!productImagesFolder.exists()) {
			productImagesFolder.mkdirs();
		}
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {
			if (requestCode == 0 && selectedImageSource == 0) {
				// الصورة من الكاميرا
				
					selectedImagePath = currentPhotoPath;
				Picasso.with(this).load(new File(currentPhotoPath)).into(selectImageButton);
				
				
				
			} else if (requestCode == 1 && selectedImageSource == 1) {
				// الصورة من المعرض
				Uri selectedImage = data.getData();
				selectedImagePath = getRealPathFromURI(selectedImage);
		     selectImageButton.setImageURI(selectedImage);
			}
		}
	}
	

	private void openCamera() throws IOException {
		Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		File photoFile = createImageFile();
		if (photoFile != null) {
			Uri photoURI = FileProvider.getUriForFile(this, "com.tajir.ayoub.fileprovider", photoFile);
			takePicture.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
			dialogim.hide();
			startActivityForResult(takePicture, 0);
		}
	}
	
	String currentPhotoPath;

	private File createImageFile() throws IOException {
		String imageFileName = "JPEG_" + System.currentTimeMillis() + "_";
		File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
		File image = File.createTempFile(imageFileName, ".jpg", storageDir);
		currentPhotoPath = image.getAbsolutePath();
		
		return image;
	}
	private void openGallery() {
		Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		dialogim.hide();
		startActivityForResult(pickPhoto, 1);
	}
	private String getRealPathFromURI(Uri contentUri) {
		String[] proj = { MediaStore.Images.Media.DATA };
		Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
		if (cursor != null) {
			int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
			cursor.moveToFirst();
			String path = cursor.getString(column_index);
			cursor.close();
			return path;
		}
		return null;
	}
	@Override
public void onBackPressed() {
	Intent intent = new Intent(this, MainActivity.class); // حيث MainActivity هو اسم النشاط الرئيسي للتطبيق

    // تنفيذ الانتقال إلى الواجهة الرئيسية
    startActivity(intent);
    finish();
    // يمكنك ترك هذا الأسلوب فارغًا لمنع الرجوع بالكامل.
    // أو يمكنك تنفيذ سلوك مخصص إذا كنت بحاجة إلى ذلك.
}

	
}


