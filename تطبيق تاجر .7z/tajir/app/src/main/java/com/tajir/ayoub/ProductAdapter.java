
package com.tajir.ayoub;
 

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
//import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import android.support.v7.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.io.File;
import android.widget.LinearLayout;
import android.content.Intent;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
	//private OnItemClickListener itemClickListener;
	UpdateProductActivity up =new UpdateProductActivity();
    private Context context;
     List<Product> productList;
	Product selectedProduct ;
	String path;
Context cot;
    public ProductAdapter(Context context) {
        this.context = context;
    }

    public void setProducts(List<Product> productList) {
        this.productList = productList;
        notifyDataSetChanged();
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.product_item, parent, false);
        return new ProductViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ProductViewHolder holder, final int position) {
        
		Product product = productList.get(position);

		holder.productNameTextView.setText(product.getName());
		holder.productPriceTextView.setText("السعر: " + product.getPrice() + "dh");
		holder.purchasePriceTextView.setText("تكلفة الشراء: " + product.getPurchasePrice() + "dh");
		holder.txtime.setText(product.gettime());
		
		holder.linear.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					selectedProduct = productList.get(position);
					
					Intent intent = new Intent(context, UpdateProductActivity.class);
					intent.putExtra("product_id", selectedProduct.getId());
					intent.putExtra("product_name", selectedProduct.getName());
					intent.putExtra("product_price", selectedProduct.getPrice());
					intent.putExtra("purchase_price", selectedProduct.getPurchasePrice());
					intent.putExtra("image_path", selectedProduct.getImagePath());
					path=selectedProduct.getImagePath();
					intent.putExtra("discription", selectedProduct.getdiscription());
					intent.putExtra("discription", selectedProduct.getdiscription());
					intent.putExtra("time", selectedProduct.gettime());
					
					context.startActivity(intent);
				}
			});
		holder.productImageView.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					selectedProduct = productList.get(position);
					path=selectedProduct.getImagePath();
					// قم بإنشاء ملف xml لتخصيص مظهر AlertDialog (على سبيل المثال، custom_dialog.xml)

// في النشاط الخاص بك، قم بإضافة الكود التالي لعرض الصورة داخل AlertDialog:
					ImageView imageView;
					AlertDialog.Builder builder = new AlertDialog.Builder(context);

// قم بتضمين تخصيص الـ AlertDialog باستخدام ملف الـ xml
					// استخدام السياق الصحيح، مثل mContext الذي يجب أن يكون معرفًا مسبقًا
					View dialogView = LayoutInflater.from(context).inflate(R.layout.image_alert, null);
					
					imageView = dialogView.findViewById(R.id.ImageView1);

// قم بتحميل الصورة باستخدام Picasso
					String imageUrl = "URL_OF_YOUR_IMAGE"; // استبدل بعنوان الصورة الخاص بك
					// قم بتحميل الصورة باستخدام Picasso وعرضها في ImageView
					//String imageUrl = "URL_OF_YOUR_IMAGE"; // استبدل بعنوان الصورة الخاص بك
					//Picasso.with(context).load(path).into(imageView);
					Picasso.with(context).load(new File(path)).into(imageView);
					

					builder.setView(dialogView);
						

					AlertDialog dialog = builder.create();
					dialog.show();
					
				}
				
	
});
		// قم بتحميل وعرض الصورة إذا كانت متاحة
		if (product.getImagePath() != null) {
			Picasso.with(context).load(new File(product.getImagePath())).into(holder.productImageView);
		} else {
			// إذا كانت المسار فارغًا، يمكنك عرض صورة افتراضية أو التعامل معها كما تشاء
			// يمكنك تعيين صورة افتراضية لـ holder.productImageView
			holder.productImageView.setImageResource(R.drawable.ic_image_off);
				}
				
			
   
}

    @Override
    public int getItemCount() {
        return productList.size();
    }
	
    public class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView productNameTextView;
        TextView productPriceTextView;
        TextView purchasePriceTextView;
		TextView txtime;
        ImageView productImageView;
       LinearLayout linear;
        public ProductViewHolder(View itemView) {
            super(itemView);
            productNameTextView = itemView.findViewById(R.id.productNameTextView);
		     txtime = itemView.findViewById(R.id.timeTextView);
			
            productPriceTextView = itemView.findViewById(R.id.productPriceTextView);
            purchasePriceTextView = itemView.findViewById(R.id.purchasePriceTextView);
            productImageView = itemView.findViewById(R.id.productImageView);
			linear=itemView.findViewById(R.id.productitemLinearLayout);
			
        }
    }
	public void updateProductImage(String updatedImagePath) {
    // تحديث المنتج المناسب في RecyclerView باستخدام المسار الجديد للصورة
    // تحتاج إلى البحث عن المنتج بناءً على المعرف (product_id) مثلاً وتحديثه
    // ثم قم بإعادة تحميل العناصر المرئية في RecyclerView لتحديث الصورة
    if (productList != null && updatedImagePath != null) {
        for (int i = 0; i < productList.size(); i++) {
            Product product = productList.get(i);
            if (product.getImagePath() != null && product.getImagePath().equals(updatedImagePath)) {
                // تحديث المسار لهذا المنتج
                product.setImagePath(updatedImagePath);
                // قم بإعادة تحميل العنصر المرئي
                notifyItemChanged(i);
                break; // لا داعي للاستمرار في البحث
            }
        }
    }
}
public ProductAdapter(){
	
}
	
	public Product getItem(int position) {
		return productList.get(position);
	}
	
	
}

