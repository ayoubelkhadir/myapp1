package com.tajir.ayoub;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.content.Context;
import android.widget.ImageView;
import android.net.Uri;
import com.squareup.picasso.Picasso;
import java.io.File;
import android.widget.Toast;
import java.io.IOException;
import android.os.Environment;
import java.nio.channels.FileChannel;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import android.provider.MediaStore;
import android.database.Cursor;
import java.util.Date;
import java.text.SimpleDateFormat;
import android.support.v7.widget.Toolbar;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.graphics.Matrix;
import android.view.ScaleGestureDetector;
import java.security.PublicKey;
import android.content.DialogInterface;
import android.support.v4.content.FileProvider;
public class UpdateProductActivity extends AppCompatActivity {
	private ImageView productImageView; 
     private static final int PICK_IMAGE_REQUEST = 1; 
	private Uri imageUri; 
	 AlertDialog dialogim;
	private EditText editdiscEditText;
	String imagePath;
    private EditText editProductNameEditText;
    private EditText editProductPriceEditText;
    private EditText editPurchasePriceEditText;
    private Button updateProductButton;
	private String updatedImagePath; // تعريف المتغير هنا
    private long productId;
    Context context;
	private ImageView imageView;
	private ScaleGestureDetector scaleGestureDetector;
	private Matrix matrix = new Matrix();
	private float scaleFactor = 1.0f;
	ImageView imge;
	Uri selectedImage;
	String newpath;
	boolean ischange=false;
	boolean ischangepath=true;
	private String selectedImagePath; // لتخزين مسار الصورة المختارة
	//private String selectedImagePath = null;
	String x;
	private int selectedImageSource = 1; 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.UpdateProductActivity);
		
		Toolbar toolbars2=(Toolbar)findViewById(R.id.toolbars2);
        setSupportActionBar(toolbars2);
		
editdiscEditText=findViewById(R.id.editdiscEditText);
        editProductNameEditText = findViewById(R.id.editProductNameEditText);
        editProductPriceEditText = findViewById(R.id.editProductPriceEditText);
        editPurchasePriceEditText = findViewById(R.id.editPurchasePriceEditText);
        updateProductButton = findViewById(R.id.updateProductButton);
		productImageView = findViewById(R.id.productImageView); // ربط ImageView بالعنصر في واجهة المستخدم
		
		
        
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

		Date currentTime = new Date();

		// تنسيق وعرض الوقت الحالي
		String formattedTime = sdf.format(currentTime);

		// عليه format بدون أن نطبق أي Date هنا قمنا بعرض الـ
		 x=  String.valueOf( formattedTime );   // عليه format مع تطبيق الـ Date هنا قمنا بعرض الـ

		

		
		
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
			
            productId = extras.getLong("product_id");
            String productName = extras.getString("product_name");
            double productPrice = extras.getDouble("product_price");
            double purchasePrice = extras.getDouble("purchase_price");
			productImageView = findViewById(R.id.productImageView); // ارتباط ال ImageView من الواجهة
			 imagePath = getIntent().getStringExtra("image_path"); // استلام المسار من الانواع الإضافية
			String discription = getIntent().getStringExtra("discription"); // استلام المسار من الانواع الإضافية
			String time = getIntent().getStringExtra("time"); // استلام المسار من الانواع الإضافية
			
			
			productImageView.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						showImageSourceSelectionDialog();
						
						//showCustomAlertDialogImg(imagePath,UpdateProductActivity.this);
					}
				});
		

		
			
			
			
			
			if (imagePath != null) {
				Picasso.with(this).load(new File(imagePath)).into(productImageView);
			} 
			if(imagePath==null){
				
				productImageView.setImageResource(R.drawable.no_imager);
						}
			
            editProductNameEditText.setText(productName);
            editProductPriceEditText.setText(String.valueOf(productPrice));
            editPurchasePriceEditText.setText(String.valueOf(purchasePrice));
			editdiscEditText.setText(discription);
			
        }

		Button deleteProductButton = findViewById(R.id.deleteProductButton);

		deleteProductButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					
					ProductDatabase productDatabase = new ProductDatabase(UpdateProductActivity.this);
					productDatabase.deleteProduct(productId);
					Intent intent = new Intent(UpdateProductActivity.this,MainActivity.class);
					startActivity(intent);
			     }
			});
		
        updateProductButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					String updatedProductdisc = editdiscEditText.getText().toString();
				
					 
					
					
					String updatedProductName = editProductNameEditText.getText().toString();
                    double updatedProductPrice = Double.parseDouble(editProductPriceEditText.getText().toString());
                    double updatedPurchasePrice = Double.parseDouble(editPurchasePriceEditText.getText().toString());
        
					if(ischange){
						newpath=selectedImagePath;
						
					}else{
						newpath=imagePath;
					}
					
					
					
					//updatedImagePath = getRealPathFromURI(imageUri); // تعيين المسار الجديد للصورة
					
				
					ProductDatabase productDatabase = new ProductDatabase(UpdateProductActivity.this);
					productDatabase.updateProduct(productId, updatedProductName, updatedProductPrice, updatedPurchasePrice,updatedProductdisc,x,newpath); // تحديث المسار هنا
					
					Intent intent = new Intent(UpdateProductActivity.this,MainActivity.class);
					startActivity(intent);

							}
			});
    }

		@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {
			 if (requestCode == 1 ) {
				// الصورة من المعرض
			   if(data.getData()!=null){
				 Uri selectedImage = data.getData();
					selectedImagePath = getRealPathFromURI(selectedImage);
				  ischange=true;
					productImageView.setImageURI(selectedImage);
				   //Picasso.with(this).load(new File(selectedImage.toString())).into(productImageView);

			   }
					 
				}
				//Picasso.with(this).load(new File(selectedImage.toString())).into(productImageView);
						}
				if (requestCode == 0) {
					// الصورة من المعرض
					if(currentPhotoPath!=null){
						ischange=true;  
						selectedImagePath=currentPhotoPath;
						
						Picasso.with(this).load(new File(selectedImagePath)).into(productImageView);
						
					}
					
					
				}
		}
	
	
	public void showCustomAlertDialogImg(String imgpath,Context c) {
        AlertDialog.Builder builder = new AlertDialog.Builder(c);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.image_alert, null);
        builder.setView(dialogView);
		
         ImageView imge = dialogView.findViewById(R.id.ImageView1);
		Picasso.with(this).load(new File(imgpath)).into(imge);
		
		
        final AlertDialog dialogim= builder.create();

        
				
		

        dialogim.show();

    }
	
			

				
	private void showImageSourceSelectionDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(UpdateProductActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.camera_galery_alert, null);
        builder.setView(dialogView);
		Button btcamera = dialogView.findViewById(R.id.camera);
		Button btgallery = dialogView.findViewById(R.id.gallery);
		btcamera.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					selectedImageSource = 0;
                    try {
                        openCamera();
                    } catch (IOException e) {
                        // يمكنك هنا استخدام الصورة الافتراضية في حالة حدوث خطأ
						// selectedImagePath = getRealPathFromResource(R.drawable.ic_image_remove);
                    }
				}


			});
		btgallery.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1) {
					selectedImageSource = 1;
                    try {
                        openGallery();
                    } catch (Exception e) {
                        // يمكنك هنا استخدام الصورة الافتراضية في حالة حدوث خطأ
						// selectedImagePath = getRealPathFromResource(R.drawable.ic_image_remove);
                    }
				}


			});


        dialogim= builder.create();





        dialogim.show();

    }
	
	private void openCamera() throws IOException {
		
		Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		File photoFile = createImageFile();
		if (photoFile != null) {
			Uri photoURI = FileProvider.getUriForFile(this, "com.tajir.ayoub.fileprovider", photoFile);
			takePicture.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
			dialogim.hide();
			startActivityForResult(takePicture, 0);
			
		}
	}

	String currentPhotoPath;

	private File createImageFile() throws IOException {
		String imageFileName = "JPEG_" + System.currentTimeMillis() + "_";
		File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
		File image = File.createTempFile(imageFileName, ".jpg", storageDir);
		currentPhotoPath = image.getAbsolutePath();

		return image;
	}
	private void openGallery() {
		Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		dialogim.hide();
		startActivityForResult(pickPhoto, 1);
	}
	private String getRealPathFromURI(Uri contentUri) {
		String[] proj = { MediaStore.Images.Media.DATA };
		Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
		if (cursor != null) {
			int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
			cursor.moveToFirst();
			String path = cursor.getString(column_index);
			cursor.close();
			return path;
		}
		return null;
	}

	
	
		
	@Override
	public void onBackPressed() {
		Intent intent = new Intent(this, MainActivity.class); // حيث MainActivity هو اسم النشاط الرئيسي للتطبيق

		// تنفيذ الانتقال إلى الواجهة الرئيسية
		startActivity(intent);
		finish();
		// يمكنك ترك هذا الأسلوب فارغًا لمنع الرجوع بالكامل.
		// أو يمكنك تنفيذ سلوك مخصص إذا كنت بحاجة إلى ذلك.
	}
	
	
}
	


