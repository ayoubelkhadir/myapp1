package com.tajir.ayoub;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.SearchView;
import java.util.List;
import java.io.FileOutputStream;
import android.content.Context;
import java.io.FileNotFoundException;
import java.io.IOException;
import android.widget.Toast;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.File;
import android.os.Environment;
import java.io.FileReader;
import java.io.BufferedReader;
import android.support.v4.content.ContextCompat;
import android.support.v4.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import java.util.Random;
import android.view.LayoutInflater;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.EditText;
import java.io.InputStream;
import java.io.OutputStream;
import android.util.Log;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.os.Handler;
import android.os.Looper;
import android.os.AsyncTask;
import java.util.Date;
import android.text.format.Time;
import java.time.MonthDay;
import java.time.Year;
import java.time.Month;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.PopupMenu;
import android.view.MenuItem;
import android.support.v7.widget.GridLayoutManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.annotation.NonNull;

public class MainActivity extends AppCompatActivity {
    private SearchView searchView;
    List<Product> productList;
    Button exportButton,importButton;
	 SwipeRefreshLayout swipeRefreshLayout ;
    private Button addProductButton,research,show_menu;
    private RecyclerView productRecyclerView;
    private ProductAdapter productAdapter;
    private ProductDatabase productDatabase;
    private static final int REQUEST_MANAGE_ALL_FILES = 0;
    File destinationImageFile;
    File sourceImageFile;
	int exportedProductsCounter = 0;
	Handler uiHandler ;
	TextView tx;
	Product productss;
	
	List<Product> products;
	private static final int CAMERA_PERMISSION_REQUEST = 192;
	    private static final int STORAGE_PERMISSION_REQUEST = 102;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		//ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST);
				// التحقق من إذن الوصول إلى الكاميرا
		
        
  
	
		Toolbar toolbars3=(Toolbar)findViewById(R.id.toolbars3);
        setSupportActionBar(toolbars3);
		 //swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
		//RecyclerView recyclerView = findViewById(R.id.recyclerView);

		// القائمة الجديدة بالبيانات
		
		

// قم بتهيئة SwipeRefreshLayout للتعامل مع السحب لأسفل
		
		
		
		uiHandler= new Handler();
		
        addProductButton = findViewById(R.id.addProductButton);
        productRecyclerView = findViewById(R.id.productRecyclerView);
       // productRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        productAdapter = new ProductAdapter(this);
        productRecyclerView.setAdapter(productAdapter);
        productDatabase = new ProductDatabase(this);
        searchView = findViewById(R.id.searchView);
			LinearLayoutManager layoutManager = new LinearLayoutManager(this);
      	productRecyclerView.setLayoutManager(layoutManager);
//		
		
		
//      GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2); // 2 أعمدة في هذا المثال
//      productRecyclerView.setLayoutManager(gridLayoutManager);
////		
		show_menu = findViewById(R.id.show_menu);
		
		show_menu.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					PopupMenu popupMenu = new PopupMenu(MainActivity.this, show_menu);
					popupMenu.getMenuInflater().inflate(R.menu.menu_main, popupMenu.getMenu());

					popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
							@Override
							public boolean onMenuItemClick(MenuItem item) {
								// اتخذ إجراء استنادًا إلى الخيار المحدد هنا
								switch (item.getItemId()) {
									case R.id.item_export:
										showCustomAlertDialog(MainActivity.this);
										// اتخذ إجراء عند اختيار الخيار 1
										return true;
									case R.id.item_import:
										showCustomAlertDialogImport(MainActivity.this);
										// اتخذ إجراء عند اختيار الخيار 2
										return true;
										// وهكذا للخيارات الأخرى
										
									case R.id.item_delet:
										try{
											ProductDatabase productDatabase = new ProductDatabase(MainActivity.this);
											productDatabase.deleteAllProducts();
											// قم بمسح البيانات من قائمة العرض
											productList.clear();
											// حدث RecyclerView لعرض البيانات المحدثة
											productRecyclerView.getAdapter().notifyDataSetChanged();
										}catch(Exception e){


										} 
										recreate(); 
										
										
										// اتخذ إجراء عند اختيار الخيار 2
										return true;
								}
								return false;
							}
						});

					popupMenu.show();
				}
			});
		
        List<Product> updatedProducts = productDatabase.getAllProducts();
        productAdapter.setProducts(updatedProducts);

        

        

             searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
				@Override
				public boolean onQueryTextSubmit(String query) {
					return false;
				}

				@Override
				public boolean onQueryTextChange(String newText) {
					updateProductList(newText);
					return true;
				}
			});
		
		
        addProductButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Intent intent = new Intent(MainActivity.this, AddProductActivity.class);
					startActivity(intent);
			
				}
			});

        productAdapter.setProducts(productDatabase.getAllProducts());
    }

    private void updateProductList(String query) {
        List<Product> searchResults;

        if (query.isEmpty()) {
            searchResults = productDatabase.getAllProducts();
        } else {
            searchResults = productDatabase.searchProducts(query);
        }

        productAdapter.setProducts(searchResults);
    }

    public static String generateRandomWord(String letters, int length) {
        Random random = new Random();
        StringBuilder randomWordBuilder = new StringBuilder();

        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(letters.length());
            char randomChar = letters.charAt(randomIndex);
            randomWordBuilder.append(randomChar);
        }

        return randomWordBuilder.toString();
    }

	
	
	
	
	
	
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == 90) {
            if (data != null) {
                String updatedImagePath = data.getStringExtra("updated_image_path");

                for (int i = 0; i < productAdapter.getItemCount(); i++) {
                    Product product = productAdapter.getItem(i);
                    if (product.getImagePath().equals(updatedImagePath)) {
                        product.setImagePath(updatedImagePath);
                        productAdapter.notifyItemChanged(i);
                        break;
                    }
                }
            }
        }
    }

    private void showCustomAlertDialogImport(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.costume_alert_imaport, null);
        builder.setView(dialogView);

        final EditText editTextfile = dialogView.findViewById(R.id.editfileNameim);
		final EditText editTextfolder = dialogView.findViewById(R.id.editfolderNameim);
		
        builder.setPositiveButton("استيراد", null);

        builder.setNegativeButton("إلغاء", null);

        final AlertDialog dialogim= builder.create();

        dialogim.setOnShowListener(new DialogInterface.OnShowListener() {
				@Override
				public void onShow(DialogInterface dialogInterface) {
					Button positiveButton = dialogim.getButton(AlertDialog.BUTTON_POSITIVE);
					positiveButton.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View view) {
								String enteredTextfile = editTextfile.getText().toString();
								String enteredTextfolder = editTextfolder.getText().toString();
								importProducts(enteredTextfolder,enteredTextfile);
								dialogim.dismiss();
							}
						});
				}
			});
        
        dialogim.show();
		
    }
	private void showCustomAlertDialog(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.custom_alert_dialog, null);
        builder.setView(dialogView);

        final EditText editTextfile = dialogView.findViewById(R.id.editfileName);
		final EditText editTextfolder = dialogView.findViewById(R.id.editfolderName);

        builder.setPositiveButton("تصدير", null);

        builder.setNegativeButton("إلغاء", null);

        final AlertDialog dialog = builder.create();

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
				@Override
				public void onShow(DialogInterface dialogInterface) {
					Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
					positiveButton.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View view) {
								String enteredTextfile = editTextfile.getText().toString();
								String enteredTextfolder = editTextfolder.getText().toString();
								exportProducts(enteredTextfolder,enteredTextfile);
								dialog.dismiss();
							}
						});
				}
			});

        dialog.show();
    }
    private void exportProducts(String folder_name,String file_name) {
        try {
            File exportFolder = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), folder_name);
            if (!exportFolder.exists()) {
                exportFolder.mkdir();
            }

            File exportFile = new File(exportFolder, file_name+".txt");
            FileWriter writer = new FileWriter(exportFile);
             products = productDatabase.getAllProducts();
			
			
            for (Product product : products) {
				
				
				//progressBar.setVisibility(View.VISIBLE);
                String imagePath = product.getImagePath();
                if (imagePath != null) {
					
                    File sourceImageFile = new File(imagePath);
                    File jpegImageFile = new File(exportFolder,product.getName()+ ".jpeg");
                    convertToJpeg(sourceImageFile, jpegImageFile);
                    imagePath = jpegImageFile.getAbsolutePath();
                }else{
		          
				}

                String productData = product.getName() + "," + product.getPrice() + "," + product.getPurchasePrice() + "," + imagePath + "," + product.getdiscription()+ "," + product.gettime();
				
				
				 // زيادة العداد بمقدار منتج واحد
// قم بتحديث TextView على الشاشة لعرض العدد الجديد
				
				
							exportedProductsCounter++;
				    
				
				    writer.write(productData + "\n");
            }

            writer.close();
			//progressBar.setVisibility(View.INVISIBLE);
			
            Toast.makeText(MainActivity.this, "تم تصدير المنتجات بنجاح", Toast.LENGTH_LONG).show();
			recreate();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "حدث خطأ أثناء التصدير", Toast.LENGTH_LONG).show();
        }
    }

    private void convertToJpeg(File sourceFile, File destFile) {
        try {
            Bitmap bitmap = BitmapFactory.decodeFile(sourceFile.getAbsolutePath());
            FileOutputStream fos = new FileOutputStream(destFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, fos);
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void importProducts(String foldername,String filename) {
        try {
            File importFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), foldername+"/"+filename+".txt");
            FileInputStream fis = new FileInputStream(importFile);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 6) {
                    String name = parts[0];
                    double price = Double.parseDouble(parts[1]);
                    double purchasePrice = Double.parseDouble(parts[2]);
                    String imagePath = parts[3];
					String disk = parts[4];
					String time = parts[5];
					
                    if (new File(imagePath).exists()) {
                        if (!imagePath.toLowerCase().endsWith(".jpeg")) {
                            File sourceImageFile = new File(imagePath);
                            File jpegImageFile = new File(imagePath + ".jpeg");
                            convertToJpeg(sourceImageFile, jpegImageFile);
                            imagePath = jpegImageFile.getAbsolutePath();
                        }

                        productDatabase.addProduct(name, price, purchasePrice, imagePath,disk,time);
                    } else {
                        // Handle the case where the file doesn't exist
                    }
                }
            }

            Toast.makeText(MainActivity.this, "تم استيراد المنتجات بنجاح", Toast.LENGTH_LONG).show();
			recreate();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "حدث خطأ أثناء الاستيراد", Toast.LENGTH_LONG).show();
        }
    

    

}
	
		private int backPressCounter = 0;

		@Override
		public void onBackPressed() {
			if (backPressCounter == 0) {
				
				// تنفيذ إجراء عند الضغط الأول على زر الرجوع
				// على سبيل المثال، إظهار رسالة للمستخدم
				finish();

				// تأخير العداد للعد لمدة زمنية معينة (مثل 2 ثانية) لإعادة تصفيره
				new Handler().postDelayed(new Runnable() {
						@Override
						public void run() {
							backPressCounter = 0;
						}
					}, 2000); // 2000 ميلي ثانية = 2 ثانية
			} else if (backPressCounter == 1) {
				finish();
				
				// تنفيذ إجراء عند الضغط الثاني على زر الرجوع
				super.onBackPressed(); // سيؤدي إلى خروج التطبيق
			}
		}
	
	
	
	
	
}

