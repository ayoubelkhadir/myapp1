package com.tajir.ayoub;
 
public class Product {
    private long id;
    private String name;
	String discription;
	String time;
    private double price;
    private double purchasePrice;
    private String imagePath;
	

    public Product() {
        // البناء الافتراضي
    }

    public Product(String name, double price, double purchasePrice, String imagePath,String discription,String time) {
        this.name = name;
        this.price = price;
        this.purchasePrice = purchasePrice;
        this.imagePath = imagePath;
		this.discription=discription;
		this.time=time;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(double purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
	
	public String getdiscription() {
        return discription;
    }

    public void setdiscription(String disc) {
        this.discription = disc;
    }
	public String gettime() {
        return time;
    }

    public void settime(String time) {
        this.time = time;
    }
    @Override
    public String toString() {
        return "Product{" +
			"id=" + id +
			", name='" + name + '\'' +
			", price=" + price +
			", purchasePrice=" + purchasePrice +
			", imagePath='" + imagePath + '\'' +
			", discription='"+ discription +'\''+
			", time='"+ time +'\''+
			
			'}';
    }
}


