 package com.tajir.ayoub;
 
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class ProductDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "products.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_PRODUCTS = "products";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_PURCHASE_PRICE = "purchase_price";
    private static final String COLUMN_IMAGE_PATH = "image_path";
	private static final String COLUMN_TIME = "time";
	
	private static final String COLUMN_DISCRIPTION = "discription";
	

    public ProductDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_PRODUCTS_TABLE = "CREATE TABLE " + TABLE_PRODUCTS + "("
			+ COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
			+ COLUMN_NAME + " TEXT,"
			
			+ COLUMN_PRICE + " REAL,"
			+ COLUMN_PURCHASE_PRICE + " REAL,"
			+COLUMN_DISCRIPTION +" TEXT, "
			+COLUMN_TIME +" TEXT, "
			+ COLUMN_IMAGE_PATH + " TEXT" + ")";
        db.execSQL(CREATE_PRODUCTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
        onCreate(db);
    }
	
	
	public void deleteProduct(long productId) {
		SQLiteDatabase db = this.getWritableDatabase();

		// قم بحذف المنتج بناءً على معرّف الصف (productId)
		db.delete(TABLE_PRODUCTS, COLUMN_ID + " = ?", new String[]{String.valueOf(productId)});

		db.close();
	}
	
	
	public void deleteAllProducts() {
    SQLiteDatabase db = this.getWritableDatabase();
    db.delete(TABLE_PRODUCTS, null, null);
    db.close();
}

	
    public void addProduct(String name, double price, double purchasePrice, String imagePath,String discription,String time) {
        SQLiteDatabase db = this.getWritableDatabase();
		
		
		
        ContentValues values = new ContentValues();
		
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_PRICE, price);
        values.put(COLUMN_PURCHASE_PRICE, purchasePrice);
        values.put(COLUMN_IMAGE_PATH, imagePath);
		values.put(COLUMN_DISCRIPTION,discription);
		values.put(COLUMN_TIME,time);
		
        db.insert(TABLE_PRODUCTS, null, values);
        db.close();
    
	}
		public List<Product> searchProducts(String query) {
			List<Product> searchResults = new ArrayList<>();
			String selectQuery = "SELECT * FROM " + TABLE_PRODUCTS + " WHERE " + COLUMN_NAME + " LIKE '%" + query + "%'";
			SQLiteDatabase db = this.getReadableDatabase();
			Cursor cursor = db.rawQuery(selectQuery, null);

			if (cursor.moveToFirst()) {
				do {
					Product product = new Product();
					product.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
					product.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
					product.setPrice(cursor.getDouble(cursor.getColumnIndex(COLUMN_PRICE)));
					product.setPurchasePrice(cursor.getDouble(cursor.getColumnIndex(COLUMN_PURCHASE_PRICE)));
					product.setImagePath(cursor.getString(cursor.getColumnIndex(COLUMN_IMAGE_PATH)));
					product.setdiscription(cursor.getString(cursor.getColumnIndex(COLUMN_DISCRIPTION)));
					product.settime(cursor.getString(cursor.getColumnIndex(COLUMN_TIME)));
					
					searchResults.add(product);
				} while (cursor.moveToNext());
			}
			cursor.close();
			return searchResults;
		}
	
	public void updateProduct(long productId, String updatedProductName, double updatedProductPrice, double updatedPurchasePrice,String disc,String time,String imgpath) {
		SQLiteDatabase db = this.getWritableDatabase();
		
		
		ContentValues values = new ContentValues();
		values.put(COLUMN_NAME, updatedProductName);
		values.put(COLUMN_PRICE, updatedProductPrice);
		values.put(COLUMN_PURCHASE_PRICE, updatedPurchasePrice);
		values.put(COLUMN_DISCRIPTION, disc); // تحديث مسار الصورة
		values.put(COLUMN_TIME,time); // تحديث مسار الصورة
		values.put(COLUMN_IMAGE_PATH,imgpath); // تحديث مسار الصورة
		
		
		
		// يمكنك استخدام الدالة update لتحديث المنتج بناءً على معرّف الصف (productId)
		db.update(TABLE_PRODUCTS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(productId)});

		db.close();
		
	}
	
		
	
	
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_PRODUCTS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                Product product = new Product();
                product.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
                product.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
                product.setPrice(cursor.getDouble(cursor.getColumnIndex(COLUMN_PRICE)));
                product.setPurchasePrice(cursor.getDouble(cursor.getColumnIndex(COLUMN_PURCHASE_PRICE)));
                product.setImagePath(cursor.getString(cursor.getColumnIndex(COLUMN_IMAGE_PATH)));
				product.setdiscription(cursor.getString(cursor.getColumnIndex(COLUMN_DISCRIPTION)));
				product.settime(cursor.getString(cursor.getColumnIndex(COLUMN_TIME)));
				
                productList.add(product);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return productList;

   }}
    

